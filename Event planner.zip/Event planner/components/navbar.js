// components/navbar.js
// components/navbar.js

fetch('components/nav.html')
  .then(response => response.text())
  .then(data => {
    const navContainer = document.createElement('div');
    navContainer.innerHTML = data;

    // Insert navbar at the top of body
    document.body.insertBefore(navContainer, document.body.firstChild);

    // Highlight the active link based on current page
    const currentPage = window.location.pathname.split("/").pop();
    const links = navContainer.querySelectorAll("nav a");

    links.forEach(link => {
      if (link.getAttribute("href") === currentPage) {
        link.classList.add("active");
      }
    });
  })
  .catch(error => console.error("Error loading navbar:", error));

