document.addEventListener("DOMContentLoaded", () => {
    const dateInput = document.getElementById("eventDate");
  
    dateInput.addEventListener("click", () => {
      const picker = document.createElement("input");
      picker.type = "date";
      picker.style.position = "absolute";
      picker.style.zIndex = "9999";
      picker.style.top = `${dateInput.getBoundingClientRect().top + window.scrollY}px`;
      picker.style.left = `${dateInput.getBoundingClientRect().left}px`;
  
      picker.addEventListener("change", () => {
        dateInput.value = picker.value;
        document.body.removeChild(picker);
      });
  
      document.body.appendChild(picker);
      picker.focus();
    });
  });
  