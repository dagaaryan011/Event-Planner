document.addEventListener("DOMContentLoaded", () => {
    
  
    // Scroll to services section on button click
    document.getElementById("exploreBtn").addEventListener("click", () => {
      document.getElementById("services").scrollIntoView({ behavior: "smooth" });
    });
  });
  